<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContatoDoController extends Controller
{
    public function index(){
        return view('site.contato');
        
    }

}


