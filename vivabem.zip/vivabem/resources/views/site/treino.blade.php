
@extends('layout.layout');

@section('title','treino')

<h1>aaa</h1>

@section('conteudo')

@endsection

