@extends('layout.layout');


@section('title','noticias')


@section('conteudo')


@endsection
