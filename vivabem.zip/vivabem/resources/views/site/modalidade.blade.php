
@extends('layout.layout');


@section('title','Modalidade')

<h1>aaa</h1>

@section('conteudo')

@endsection

