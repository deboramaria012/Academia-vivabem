<h1>aaa</h1>
<?php /**PATH C:\Users\debora.mssousa\Documents\Academia vivabem\vivabem\resources\views/site/modalidade/musculacao.blade.php ENDPATH**/ ?>