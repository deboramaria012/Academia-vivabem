;


<?php $__env->startSection('title','layout'); ?>


<?php $__env->startSection('conteudo'); ?>

<?php $__env->stopSection(); ?>







<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\debora.mssousa\Documents\Academia vivabem\vivabem\resources\views/site/home.blade.php ENDPATH**/ ?>